import React from 'react'

const Footer = () => {
  return (
    <div className="bg-dark ">
       <p style={{color:'white'}} className='text-center'> Copyright &copy; 2024. All right reserved.</p>
    </div>
  )
}

export default Footer