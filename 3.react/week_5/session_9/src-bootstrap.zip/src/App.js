import React from 'react'
import {BrowserRouter as Router , Routes , Route} from 'react-router-dom'
import NavBar from './components/NavBar';
import Home from './components/Home';
import About from './components/About';
import Notfound from './components/Notfound';
import Products from './components/Products';
import ProductDetails from './components/ProductDetails';
const App = () => {
  return (
    <div>
      <Router>
        <NavBar />
        <section className='container'>
           <Routes>
              <Route path='' element={<Home /> }/>
              <Route path='about-us' element={<About /> }/>
              <Route path='*' element={<Notfound /> }/>
              <Route path='products' element={<Products />}/>
              <Route path='product-details/:id' element={<ProductDetails />}/>
           </Routes>
        </section>
        </Router>
    </div>
  )
}

export default App