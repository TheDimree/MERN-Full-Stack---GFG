import React from 'react'
import ProductList from './ProductList';
const Products = () => {
  return (
    <div>
      <div className="flex flex-wrap mb-4">
            <div className="w-1/3 h-12">
              <ProductList />
            </div>
      </div>
    </div>
  )
}

export default Products