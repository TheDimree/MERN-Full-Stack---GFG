import { createBrowserRouter } from "react-router-dom";
import Main from "../components/Main";
import Home from "../components/Home";
import About from "../components/About";
import ErrorPage from "../components/Myerror";
const router=createBrowserRouter([
    {
        path:'', 
        element:<Main />,
        errorElement:<ErrorPage />,
        children:[
            {
              index:true,
               element:<Home />
            },
            {
                path:'about',
                 element:<About />
            }
        ]
    }
])
export default router;