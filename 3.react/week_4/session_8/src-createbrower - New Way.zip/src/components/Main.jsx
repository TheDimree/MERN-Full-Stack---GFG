import React from 'react'
import Header from './Header'
import { Outlet } from 'react-router-dom'
import Footer from './Footer'

const Main = () => {
  return (
    <main>
      <Header />
      <section className='container'>
        <Outlet />
      </section>
      <Footer />
    </main>
  )
}

export default Main