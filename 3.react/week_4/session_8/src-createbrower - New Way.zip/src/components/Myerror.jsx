import React from 'react'
import { Link, useRouteError } from 'react-router-dom'
const ErrorPage = () => {
    const error=useRouteError();
  return (
    <div>
    
            {error.status == "404" && <>
               <h2> Page not found</h2>
               <p> Go to website <Link to="/"> Click Here </Link></p>
            </>}
       
    </div>
  )
}

export default ErrorPage