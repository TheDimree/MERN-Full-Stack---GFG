import React from 'react'

const Notfound = () => {
  return (
    <div>
        <h2> 404! Page Not Found.</h2>
    </div>
  )
}

export default Notfound