import React from 'react'

const Noida = () => {
  return (
    <div>Noida</div>
  )
}

export default Noida